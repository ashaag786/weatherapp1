//
//  WeatherTableCell.swift
//  WeatherApp
//
//  Created by Gypsa Agarwal on 22/10/18.
//  Copyright © 2018 Gypsa. All rights reserved.
//

import Foundation
import UIKit
class WeatherTableCell: UITableViewCell {
    @IBOutlet weak var cityNameLbl:UILabel!
     @IBOutlet weak var tempLbl:UILabel!
}
