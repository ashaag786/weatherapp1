//
//  Constants.swift
//  WeatherApp
//
//  Created by Gypsa Agarwal on 23/10/18.
//  Copyright © 2018 Gypsa. All rights reserved.
//

import Foundation
let APIKEY = "a2a6be0b51ad62d6381bc4b53b564e2b"
let APIBASEURL = "https://api.openweathermap.org/data/2.5/"
