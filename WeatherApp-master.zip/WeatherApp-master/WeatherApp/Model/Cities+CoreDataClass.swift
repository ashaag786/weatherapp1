//
//  Cities+CoreDataClass.swift
//  WeatherApp
//
//  Created by Gypsa Agarwal on 23/10/18.
//  Copyright © 2018 Gypsa. All rights reserved.
//
//

import Foundation
import CoreData


public class Cities: NSManagedObject {

}
